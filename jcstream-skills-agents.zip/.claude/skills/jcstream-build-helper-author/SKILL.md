---
name: jcstream-build-helper-author
description: Use when adding or modifying Python helper functions in web/build.py that compute values for Jinja templates in the JCStream project. Covers the env.globals registration pattern, the Inmate/Snapshot models, _DEGREE_RE, _CHAPTER_LABEL, _OFFENSE_CATEGORY maps, and the date-parsing helpers. Trigger phrases: "add a helper for X", "compute Y per inmate", "expose Z to templates".
---

# JCStream build-helper author

You own the helper layer in `web/build.py` (~1700 lines). Helpers are Python functions registered as Jinja env globals so templates can call them inline.

## The registration pattern
Every helper follows this contract:

1. Define the function near related helpers (group by domain — tier helpers near `_primary_tier`, bond helpers near `_bond_total`, date helpers near `_parse_book_date`).
2. Register on `env.globals` inside `build()` (around `build.py:79-140`):
   ```python
   env.globals["my_helper"] = _my_helper
   # or lambda-wrapped when you need to bind snapshot or offenses:
   env.globals["bond_context"] = lambda inm: _bond_context(inm, snapshot.inmates, offenses)
   ```
3. Call from a template:
   ```jinja
   {% set ctx = bond_context(inmate) %}
   ```

**Missing either side fails silently.** Forget the registration → Jinja prints `''`. Forget the template call → the helper is dead code. Add both in the same commit.

## Models you'll work with
- `Inmate` — `scraper/models.py`. Fields: `inmate_number`, `booking_number`, `last_name`, `first_name`, `middle_name`, `full_name`, `date_of_birth`, `sex`, `race`, `booking_date`, `projected_release_date`, `holder_status`, `photo_filename`, `charges: list[Charge]`.
- `Charge` — `orc_code`, `description`, `court_date`, `bond_type`, `bond_amount`, `disposition`, `common_pleas_case`, `municipal_case`, `other_case`.
- `Snapshot` — `generated_utc`, `inmate_count`, `inmates`.

## Helpers you can build on
- `_parse_book_date(s)` — parses M/D/YY or M/D/YYYY, rejects sentinel dates > 15 years old. Returns `datetime | None`.
- `_parse_bond_amount(s)` — parses `$25,000` → `25000`. Returns `int | None`.
- `_charge_tier(c, offenses)` — degree resolution: description suffix > ORC default > venue.
- `_primary_tier(inmate)` — most-severe tier label for the corner badge.
- `_primary_degree(inmate)` — F1/F2/.../MM picker.
- `_days_in_custody(inmate)` — filtered for sentinel dates.

## Static maps
- `_DEGREE_RE` — matches `F1` … `MM` suffix in a description.
- `_CHAPTER_LABEL` — coarse fallback (Ch. 2903 → "offense against persons").
- `_OFFENSE_CATEGORY` — fine-grained per-code label + chapter color class.
- `_CLS_RANK` — chapter color severity rank for picking a primary.

When adding a new ORC code's category, edit `_OFFENSE_CATEGORY`, not the chapter map — the chapter map is intentionally coarse.

## Anti-patterns
- Hardcoding paths — use `Path("data/...")`.
- Mutating `Snapshot.inmates` — treat as read-only.
- Forgetting to handle `None` from `_parse_book_date` — sentinel dates return `None` by design.
- Inline `re.search` for bond amounts — call `_parse_bond_amount` for consistency.

## Verify
```sh
JCSTREAM_SITE_BASE_URL="" JCSTREAM_CNAME="www.aretheyinjail.com" python -m web.build
python -m pytest -q
```
For a non-trivial helper, also add a unit test (hand off to **jcstream-test-author**).
