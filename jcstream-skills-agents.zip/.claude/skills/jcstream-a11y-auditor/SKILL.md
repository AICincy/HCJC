---
name: jcstream-a11y-auditor
description: Use when auditing JCStream for accessibility — WCAG AA contrast on the light theme, ARIA correctness (aria-current/aria-pressed/aria-modal), keyboard navigation, screen-reader-only content, reduced-motion. The new light theme retired the dark theme's hand-tuned contrast tokens, so contrast must be verified empirically rather than assumed from tokens. Trigger phrases: "accessibility audit", "WCAG check", "screen reader", "contrast issue".
---

# JCStream a11y auditor

You audit `web/templates/*.html` + `web/static/style.css` for WCAG 2.1 AA compliance. The dark→light theme swap retired the dark-theme `--fg-dim-raised` tuning (now equal to `--fg-dim`), so **don't infer contrast safety from token names; measure each color pair on real surfaces.**

## Surfaces to verify
For each surface (background) × ink (foreground) pair:

| Background | Inks used on it |
|---|---|
| `--bg` (#fafaf8) | `--fg`, `--fg-soft`, `--fg-muted`, `--fg-dim` |
| `--surface` (#fff) | `--fg`, `--fg-soft`, `--fg-muted`, `--fg-dim`, `--accent` |
| `--bg-soft` (#f4f3ef) | `--fg`, `--fg-muted` |
| `--accent-bg` (#eef0fc) | `--accent`, `--fg` |
| `--warn-bg` (#fbeded) | `--warn` (#b54545), `#6b3434` (used on `.alert p`) |
| Tier chip backgrounds (10) | Tier ink colors paired in `style.css:677-686` |
| Ladder cell backgrounds (10) | Ladder ink colors paired in `style.css:1008-area` |

For each pair: target **4.5:1 (body text)** or **3.0:1 (large text ≥18px regular or 14px bold)**.

## Tools
- **`pa11y` or `axe-core` CLI** for automated checks. Headless against `docs/index.html`, `docs/inmate/<id>/index.html`, `docs/stats/index.html`, `docs/statute/index.html`.
- **WebAIM contrast checker** (manual) for spot-checks of specific pairs.
- **Browser devtools** for keyboard-only traversal: Tab through every page, ensure focus ring is visible (current outline at 2px, accent color).

## ARIA inventory (already correct — keep it that way)
| Element | Attribute | Where |
|---|---|---|
| Active severity-ladder cell | `aria-current="true"` | `inmate.html`, `statute.html` |
| Card/Table view toggle | `aria-pressed` | `index.html` (button) + `base.html` JS sets it |
| Lightbox dialog | `role="dialog" aria-modal="true" aria-label="Booking photo"` | `base.html:78` |
| Search results combobox | `aria-autocomplete="list" aria-expanded aria-controls` | `index.html`, `base.html` JS |
| Tier tooltip | `role="tooltip"` | `base.html:80` |
| Filter status | `aria-live="polite"` on `.filter-count` | `index.html` |
| Section-h pills | `aria-hidden="true"` where decorative | various |

When adding interactive state, mirror the pattern.

## Screen-reader-only h1
`base.html:55` has `<h1 class="sr-only">JCStream — …</h1>` rendered ONLY on the homepage (overridden to empty on detail pages). Don't remove — it gives screen readers a page-level landmark before the visible heading.

## Reduced motion
`html { scroll-behavior: smooth; }` is wrapped in `@media (prefers-reduced-motion: no-preference)` (`style.css:58`). Sparkline / spark-card transitions don't run when the user opts out. Keep new animations behind the same guard.

## Keyboard traps to watch
- Lightbox tab cycle (`base.html:135-149`) — must wrap when `inert` not supported.
- Filter dropdown + search results combobox — ESC closes both.
- Tier tooltip — pointer-events:none so it can't steal focus.

## Anti-patterns
- `<div onclick="…">` instead of `<button>` or `<a>` — kills keyboard access.
- `aria-label` on a `<div>` that has visible text — labels override the text.
- Color-only state ("the active tab is bluer") — pair with weight, underline, or icon.
- `tabindex="0"` on a non-interactive element.

## Verify
```sh
JCSTREAM_SITE_BASE_URL="" JCSTREAM_CNAME="www.aretheyinjail.com" python -m web.build
npx pa11y docs/index.html docs/inmate/<id>/index.html docs/stats/index.html docs/statute/index.html
# Or with axe:
npx @axe-core/cli docs/index.html
```
Document failures with file:line, recommended fix, and WCAG criterion (e.g. "1.4.3 Contrast (Minimum) — `--fg-dim` on `--surface` measures 2.9:1, fails AA at 14px").
