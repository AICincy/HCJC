---
name: jcstream-sweep-debugger
description: Use when investigating why a JCStream sweep didn't produce fresh data — the roster count is flat, the changelog is empty, the site rendered stale photos, or the GitHub Actions sweep workflow showed exit-0 but no commit. Covers the silent degraded-roster fallback in scraper/sweep.py, the health thresholds in sweep_guards.py, and how to read changelog.json / history.json / current.json together. Trigger phrases: "sweep didn't update", "stuck count", "no changes in changelog", "scraper looks idle".
---

# JCStream sweep debugger

You diagnose sweep failures. The most common failure mode is **silent**: `_sweep_looks_healthy` returned False, `sweep.py` kept the last-good `data/current.json`, and the workflow exited 0 with no commit. The site looks fine but is stale.

## The triage flow

### 1. Did the sweep workflow run at all?
Check GitHub Actions for the most recent sweep run:
```sh
# Workflow defined at .github/workflows/sweep.yml
# Look for "data+site: sweep YYYY-MM-DDTHH:MMZ" commits on the dev branch
git log --oneline -20 | grep "data+site: sweep"
```
Gaps in the timeline (>30 min) mean the cron didn't fire — that's a GH Actions / repo-permissions problem, not a scraper problem.

### 2. Did the scraper bail on the health check?
The workflow log will show the sweep's `_sweep_looks_healthy` decision. Without log access, infer from data:

- Compare today's `data/current.json` `inmate_count` to yesterday's: if it's identical for >2 cycles, the gate likely tripped.
- Tail `data/changelog.json`: if the most recent `timestamp_utc` is >1 hour old, no new events.

### 3. Which threshold tripped?
From `scraper/sweep_guards.py:23-25`:

| Threshold | Meaning |
|---|---|
| `SWEEP_MAX_FAILED_FRACTION = 0.10` | >10% of surname fetches errored → bail |
| `SWEEP_MIN_ROSTER_FRACTION = 0.50` | new roster <50% of last cycle → bail |
| `SWEEP_BOOTSTRAP_FLOOR = 50` | first-ever sweep needs ≥50 inmates → bail |

To distinguish:
- **High error rate** → HCSO rate-limited the scraper. Look at the workflow log for HTTP 429 / generic-block-page hits. The fix is usually time (wait an hour) — not a code change.
- **Roster collapse** → HCSO published a degraded list (frequent during a system migration). Check `https://www.hcso.org/justice-center-services/inmate-search/` manually.
- **Bootstrap floor** → a brand-new deploy with `data/current.json` missing. Run a manual sweep with `workflow_dispatch`.

### 4. Cross-check the data files
| File | What it tells you |
|---|---|
| `data/current.json` | Latest *accepted* roster snapshot. `generated_utc` is when the snapshot was written (not when the sweep ran — those diverge during a bailed sweep). |
| `data/changelog.json` | Append-only log of booked/released/updated events. Length grows on every accepted sweep. |
| `data/history.json` | Daily roster-size + churn counts. Stubby today (≈200 bytes). |
| Workflow logs (Actions) | Per-surname HTTP status, error count, gate decision. |

If `current.json.generated_utc` is recent but `changelog.json` is unchanged → the sweep was accepted but no events flipped (genuinely quiet day).

If `current.json.generated_utc` is stale and `changelog.json` is stale → the gate has been tripping. Read the recent workflow logs.

## When to file a code fix
- Threshold is too tight for the actual error envelope (HCSO consistently returns 8% errors and the floor is 10%) → tune `SWEEP_MAX_FAILED_FRACTION` in `sweep_guards.py` *with* telemetry to back it up.
- A new HCSO HTML quirk is causing parsing failures → fix the parser, don't relax the gate.
- The bootstrap floor is biting a legitimate restart → drop a known-good `data/current.json` into place rather than weakening the check.

## When NOT to file a code fix
- HCSO is rate-limiting → wait it out, this is normal.
- HCSO is publishing a degraded list → the silent fallback is *protecting* the site; let it.

## Anti-patterns
- Lowering `SWEEP_MIN_ROSTER_FRACTION` to make a bad sweep go through.
- Editing `data/current.json` by hand.
- Re-running the workflow without diagnosing — you'll get the same answer.

## Verify a fix
```sh
python -m pytest -q tests/test_sweep.py tests/test_sweep_guards.py
# Then trigger a manual sweep via the GH Actions UI (workflow_dispatch).
```
