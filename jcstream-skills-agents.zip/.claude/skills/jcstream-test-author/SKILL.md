---
name: jcstream-test-author
description: Use when writing or updating pytest tests under tests/ in the JCStream project. Covers the snapshot/fixture conventions, network mocking with respx or monkeypatch, build.py helper tests, scraper integration tests, and creating tests/conftest.py for shared fixtures (none exists yet). 148 tests must stay green. Trigger phrases: "write a test for", "fix the failing test", "add coverage".
---

# JCStream test author

You own `tests/*.py` (15 files, 1707 lines, 148 tests as of 2026-05-14). Config lives at `pyproject.toml [tool.pytest.ini_options]`.

## Run the suite
```sh
python -m pytest -q          # all tests
python -m pytest -q tests/test_build.py::test_specific_thing
```

## Test layout
```
tests/
├── test_build.py        # web/build.py helpers, Jinja render
├── test_sweep.py        # sweep orchestrator
├── test_sweep_guards.py # health-check thresholds
├── test_store.py        # photo cache / data writes
├── test_orc.py          # ORC mapping & normalization
├── test_match.py        # CFS ↔ inmate matcher
├── test_models.py       # Pydantic model validation
├── test_pra.py          # PRA email loop (dry-run path)
└── …
```

No `tests/conftest.py` exists yet. If you add a fixture used across two or more files, create it.

## Fixture conventions
- Use real-shape JSON fixtures (mini snapshots, 3-10 inmates) rather than mocked dataclasses — the build helpers are tightly coupled to real fields.
- Inline `Snapshot(inmates=[...])` constructors are fine for unit tests.
- For network-touching code, mock with `respx` (already a transitive dep through httpx) or `monkeypatch` on the module-level client.

## What to test
- **Pure helpers** (date parsers, bond parsers, ORC normalization, tier resolvers): table-driven with parametrize.
- **Build env globals**: render a tiny template using the helper, assert the output. Don't just call the helper — assert it's reachable through Jinja.
- **Scraper guards**: feed a fake "prev count" + "seen count" + "failed count" into `sweep_looks_healthy` and assert the gate decision (`sweep_guards.py`).
- **Jinja templates**: render with a fixture snapshot, parse the result with `selectolax` (already a project dep), assert specific elements exist.

## Don't test
- The static maps (`_OFFENSE_CATEGORY`, `_CHAPTER_LABEL`) as data — those are reference tables. Test that they're *used correctly* through their consumers.
- HTTP responses verbatim — mock the boundary, not the wire.
- Pixel output of the photo pipeline — Pillow versions drift.

## Anti-patterns
- Network calls in tests. Period.
- Time-based assertions without `freezegun` or an injected clock — sentinel-date filtering becomes flaky.
- Snapshots checked into git as fixtures of real inmates — use synthetic IDs and names.

## Verify
```sh
python -m pytest -q
```
Must report `148 passed` (or higher as you add).
