---
name: jcstream-legal-copy-author
description: Use when editing user-facing legal language in JCStream templates — presumed-innocent banners, FCRA disclaimer, ORC § 149.43 attribution, ORC § 2953.32 expungement removal protocol, no-fee guarantee, comment-policy block. Touches web/templates/{index,inmate,stats,statute,data}.html and web/templates/base.html footer. Trigger phrases: "update the disclaimer", "rephrase the banner", "fix the FCRA notice", "removal policy".
---

# JCStream legal copy author

You own the user-facing legal language. Legal exposure on a public-records mirror is real; consistency across pages is the defense.

## Files and where the copy lives
| Element | File |
|---|---|
| Top-of-page banner (presumed innocent + ORC 149.43 + FCRA + ORC 2953.32) | `web/templates/index.html:5-9` |
| Inmate detail "alert" + record-legal paragraph | `web/templates/inmate.html` (presumed-innocent box + ORC 149.43 + removal protocol) |
| Stats page alert | `web/templates/stats.html` |
| Statute page alert | `web/templates/statute.html` |
| Data & methodology + Legal notices section | `web/templates/data.html` |
| Footer-legal block (every page) | `web/templates/base.html` footer |
| Meta description / OG description | `web/templates/base.html` `<head>` |
| Comment policy on inmate page | `web/templates/inmate.html` `.comment-policy` |

## Required phrases (verbatim across every page that touches the topic)
- **"legally presumed innocent unless and until proven guilty in a court of law"**
- **"Arrest is not conviction."**
- **"charges are accusations only"**
- **"Not a consumer reporting agency"** + **"Fair Credit Reporting Act, 15 U.S.C. § 1681 *et seq.*"**
- **"ORC § 149.43"** (Ohio Public Records Act — the source-of-record citation)
- **"ORC § 2953.32"** (sealing / expungement — the removal-on-request basis)
- **"there is never a fee, and there never will be"** (no-fee guarantee, repeated on every page that mentions removal)
- **Removal endpoint**: `https://github.com/AICincy/JCStream/issues`

If you change one of these, change them everywhere — grep first.

## Tone
- Plain English, present tense, third person.
- No editorialization on guilt or character.
- No softening of the legal facts ("might be innocent" — no; "is legally presumed innocent" — yes).
- No marketing voice ("we believe in transparency" — no; "JCStream republishes public records" — yes).

## What you can change
- Phrasing improvements that preserve meaning and keep the required phrases above intact.
- Adding a new disclaimer for a new feature (e.g. if a future feature surfaces something the existing copy doesn't cover).
- Tightening repeated text.

## What you cannot change without an explicit owner approval
- Dropping the FCRA disclaimer or making it less prominent.
- Removing the no-fee guarantee.
- Changing the removal endpoint.
- Asserting guilt or summarizing charges in a way that implies guilt.
- Adding language that suggests this site is operated by or endorsed by HCSO or any government entity.

## Reference statutes
- **ORC § 149.43** — Ohio Public Records Act. Authorizes republication.
- **ORC § 2953.32** — Sealing / expungement of records. Authorizes removal-on-court-order.
- **15 U.S.C. § 1681 *et seq.*** — Fair Credit Reporting Act. The "not a CRA, don't use for employment/housing/credit" disclaimer.

## Anti-patterns
- Inconsistent phrasing between pages ("presumed not guilty" on one page, "presumed innocent" on another). Grep before commit.
- Removing the "and there never will be" tail of the no-fee guarantee — it's a forward commitment.
- Linking to a paid-removal service. There is none affiliated with this project.

## Verify
```sh
grep -rE "presumed innocent|legally presumed|ORC.{1,3}149\.43|2953\.32|never (be|a) fee" web/templates/
```
Every public-facing page should hit on each phrase.
