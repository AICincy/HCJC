---
name: jcstream-stylesheet-author
description: Use when editing web/static/style.css in the JCStream project. Covers the light-theme token system (--bg/--fg/--accent), the 10-tier .tier-F1…MM ladder palette, .ladder-* cells, body.is-table table-mode rules, content-visibility, mobile breakpoint at 720px, and the print at-rule. Trigger phrases: "restyle the cards", "fix the tier colors", "make the hero bigger", "add a CSS rule".
---

# JCStream stylesheet author

You own `web/static/style.css`. The current theme is the "modern utility" light direction (warm-cream surfaces, slate-blue accent, Geist/Inter + JetBrains Mono). The dark editorial theme was retired in 2026; class names persisted but values shifted.

## Token system (single source of truth)
The `:root` block at `style.css:5-54` defines every color, typography stack, and radius. **Always extend tokens here before adding a new hex.** Tokens you cannot rename without auditing the rest of the file:

| Surface | `--bg` `--bg-soft` `--surface` `--surface-hi` |
| Ink     | `--fg` `--fg-soft` `--fg-muted` `--fg-dim` `--fg-dim-raised` |
| Accent  | `--accent` `--accent-hi` `--accent-bg` `--accent-bg-2` |
| Status  | `--danger` `--warn` `--warn-bg` `--ok` `--misd` |
| Tier    | `--tier-felony-fg/bg/bd`, `--tier-misd-fg/bg/bd` |
| Type    | `--font-sans` `--font-serif` `--font-mono` |
| Radius  | `--radius` `--radius-sm` |
| Layout  | `--masthead-h` `--monthnav-h` |

`--font-serif` is an alias for `--font-sans` in the current theme — don't rely on a serif being available unless you add one.

## Ten-tier ladder palette
Tier chips at `style.css:676-686` and ladder cells at `style.css:1008-area`. The colors are intentional — warmer reds for F1-F3 (most severe), warm oranges/creams for F4-F5, olive/sage for M1-M3, neutral for MM. Don't recolor without auditing where each tier is also used: search results, card corner chip, ladder cells, recent-booking cards, calendar items.

## `body.is-table` table mode
Rules at `style.css:481-516` reshape `.month .card-inmate` into a 5-column grid (52-1fr-140-70-100 px). When adding card content, ensure it survives both layouts.

## content-visibility
Cards use `content-visibility: auto` with `contain-intrinsic-size` set (`style.css:577`, `:768`). Off-screen cards skip paint cost. Don't put tier tooltips *inside* `.card-inmate` — they'd be clipped by the paint container. The shared `#tier-tip` floats outside.

## Mobile breakpoint
Single breakpoint at `@media (max-width: 720px)` (six occurrences: `:183, :513, :880, :1081, :1177`). Stack the hero strip, drop the brand-sub, collapse the bio grid to 1 col, etc. Don't add new breakpoints — extend the existing 720 px block.

## Print
The `@media print` block at the bottom of the file forces a paper-style render. Add print suppression for any new feature that's interactive-only.

## Anti-patterns
- New hex literals outside `:root`. Add a token first.
- Recoloring `.tier-F2` (or any ladder cell) without checking ladder + recent-bookings + statute page.
- Adding a `box-shadow` in light theme without considering print (`@media print` zeroes most shadows).
- Using `font-serif` expecting a different family — it's an alias.

## Verify
```sh
JCSTREAM_SITE_BASE_URL="" JCSTREAM_CNAME="www.aretheyinjail.com" python -m web.build
```
Then open `docs/index.html`, `docs/inmate/<id>/index.html`, `docs/stats/index.html`, `docs/statute/index.html` in a browser. Toggle the card / table view on the homepage. Check the 720 px breakpoint.
