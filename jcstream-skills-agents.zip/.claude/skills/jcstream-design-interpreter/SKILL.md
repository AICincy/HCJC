---
name: jcstream-design-interpreter
description: Use when porting a design asset into the JCStream project — a Figma export, JSX mockup, screenshot, design zip, or hand-drawn spec. Translates the input into Jinja templates + CSS tokens + Python helpers while preserving the static-site / no-JS-required contract and accessibility. Trigger phrases: "port this design", "implement the mockup", "translate the Figma", "from this screenshot".
---

# JCStream design interpreter

You translate design specs into the JCStream stack. Inputs vary (JSX, Figma export, screenshots, design zips); the *output contract* is fixed.

## Output contract
1. **Static Jinja templates** (`web/templates/*.html`) — no React, no client framework.
2. **Token-driven CSS** (`web/static/style.css`) — every color/space/type goes through `:root` tokens (see **jcstream-stylesheet-author**).
3. **Python helpers in `web/build.py`** when the design surfaces a computed value not already exposed (see **jcstream-build-helper-author**).
4. **No required JavaScript.** Progressive enhancement only — the site must be fully readable with JS disabled.
5. **Accessibility preserved or improved** — see **jcstream-a11y-auditor**.

## Translation playbook
For each design component:

1. **Identify the input shape.** JSX? Pull the JSX file. Figma? Ask for the spec or the screenshot. Zip? Unzip into `/tmp` and read the manifest.
2. **Map class names.** The design's `.ut-*` prefix (from the modern-utility direction we ported) is *already* mapped to existing JCStream class names. New designs will need a fresh mapping table; write it out before coding.
3. **Tokenize the colors.** Don't paste hexes inline; add them to `:root` if they're truly new, otherwise reuse.
4. **Extract data needs.** Note every value the design displays (`fmtAge`, `daysSince`, `bondContext`, …). For each, find or write a build.py helper.
5. **Render with a sample snapshot first.** Run `python -m web.build` against `data/current.json` and open the page. Don't ship until the live data looks right.

## Pitfalls
- **JSX `useState` / `useMemo`**: stateful UI is out of scope. Either pre-compute the value in build.py or use a tiny progressive-enhancement JS hook (e.g. the table/cards toggle).
- **JSX `onClick={() => onSelect(id)}`**: convert to a plain `<a href="{{ base_url }}/inmate/{{ id }}/">` and let the browser do navigation.
- **JSX inline SVGs with computed paths**: fine to copy verbatim, but if they depend on data, render them server-side from Jinja.
- **Design fonts not in the system stack**: the project uses Geist/Inter + JetBrains Mono via Google Fonts (preconnected in `base.html`). Don't add a third font without a strong reason.
- **`React.Fragment` or `<>...</>`**: drop the fragment, render children directly.
- **CSS-in-JS or styled-components**: extract to vanilla CSS classes.

## Reference mapping (modern-utility direction → JCStream class names)
| Design class | JCStream class |
|---|---|
| `.dir-utility` | (body — no class needed; styles cascade from `body`) |
| `.ut-header` | `.masthead` |
| `.ut-brand-mark` | `.masthead .brand::before` (generated content) |
| `.ut-tier-F1…MM` | `.tier-F1…MM` |
| `.ut-ladder-cell` | `.ladder-cell` |
| `.ut-recent-card` | `.rb-card` |
| `.ut-detail-hero` | `.inmate-hero` |
| `.ut-kpi-card` | `.kpi` |
| `.ut-toplist-row` | `.toplist-row` |
| `.ut-bondctx-axis` | `.bondctx-axis` |
| `.ut-tl-axis` | `.tl-axis` |
| `.ut-cal-day` | `.cal-day` |

When a new direction lands, extend this table before writing code.

## Anti-patterns
- Shipping JS for something Jinja can render at build time.
- Recoloring tokens to match a design's hex literals — adjust the design's hex on paper if the project's palette is the source of truth.
- Adding a build.py helper without registering it on `env.globals`.

## Verify
Build, render, eyeball, then run tests:
```sh
JCSTREAM_SITE_BASE_URL="" JCSTREAM_CNAME="www.aretheyinjail.com" python -m web.build
python -m pytest -q
```
