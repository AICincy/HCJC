---
name: jcstream-scraper-author
description: Use when modifying or extending data pullers in scraper/ — HCSO inmate roster (sweep.py), Cincinnati Open Data feeds (cfs.py, cfs_pdi.py, shootings.py), the courtclerk URL helpers, PRA email loop. Covers rate-limit budget, sweep health guards (sweep_guards.py: 50% floor, 10% error ceiling), atomic write to data/current.json, and the 30-min cron in .github/workflows/sweep.yml. Trigger phrases: "add a new data feed", "fix the HCSO scraper", "tune the sweep guard".
---

# JCStream scraper author

You own `scraper/*.py` and `.github/workflows/sweep.yml`. Data flows: HCSO surname-iter → details fetch → Pillow photo store → `data/current.json` write, gated by health checks.

## Sweep health guards (single source of truth)
Constants in `scraper/sweep_guards.py:23-25`:
```python
SWEEP_MAX_FAILED_FRACTION = 0.10   # bail if >10% of surname fetches errored
SWEEP_MIN_ROSTER_FRACTION = 0.50   # bail if roster collapsed to <50% of last cycle
SWEEP_BOOTSTRAP_FLOOR     = 50     # first-ever sweep needs ≥50 inmates
```
`sweep_looks_healthy()` at `sweep_guards.py:57-66` checks both. If it returns False, `sweep.py` keeps the last-good `data/current.json` and exits 0 (silent fallback — this is intentional, mentioned in CLAUDE.md).

When tuning thresholds, **change `sweep_guards.py` only** — `sweep.py` is the orchestrator and re-imports the constants.

## Surname iteration
`data/surnames.txt` is **A–Z single letters, on purpose** (CLAUDE.md). HCSO's last-name search is a substring match, so 26 letters cover the whole roster after dedup. Don't "fix" this to two-letter prefixes — it slows the sweep and adds nothing.

## Rate-limit etiquette
HCSO returns a generic block page when over rate. The detail fetcher backs off with jitter. New OD-feed pullers should:
- Use a single `httpx.Client` for connection reuse
- Respect any rate-limit hints in response headers
- Time-box themselves so a slow feed can't blow the workflow's timeout

## Atomic snapshot writes
Write to `data/current.json.tmp` then `os.replace()` — never directly. This keeps the GH Actions workflow from committing a partial file mid-write.

## Cincinnati Open Data feeds
Four feeds today:
- `qiik-bpks` — CFS calls (arrest/citation/report dispositions)
- `gexm-h6bt` — CFS PDI dispatch (wider window)
- `sfea-4ksu` — reported shootings
- One more in `cincy_open.py`

When adding a feed, follow the pattern in `cfs.py` (or `shootings.py`): typed row dataclass, `load()` returns a list, build.py de-dupes on event number.

## Workflow contract
`.github/workflows/sweep.yml` runs every 30 min. It checks out the dev branch, pulls live, runs the scraper, runs build, commits, pushes. Don't add steps that re-create venvs (cold-start cost). Don't push to `main` from CI.

## PRA email loop
`scraper/pra.py` + `scraper/pra_capias.py` + `.github/workflows/pra_daily.yml`. Dry-runs (log-only) until `JCSTREAM_PRA_SMTP_HOST` + `JCSTREAM_PRA_FROM_EMAIL` are set as repo secrets. Don't hard-code SMTP credentials.

## Anti-patterns
- Bypassing `sweep_looks_healthy` because "the roster looks fine".
- Lowering `SWEEP_MIN_ROSTER_FRACTION` without telemetry — false negatives publish a degraded site.
- Direct `open(path, 'w')` for the snapshot — use tmp + rename.
- Scraping `codes.ohio.gov` — it's explicitly off-limits; ORC titles are hand-curated.

## Verify
```sh
python -m pytest -q tests/test_sweep.py tests/test_sweep_guards.py
# Dry-run a sweep against a fixture:
python -m scraper.sweep --dry-run   # if --dry-run is implemented; else just inspect output
```
